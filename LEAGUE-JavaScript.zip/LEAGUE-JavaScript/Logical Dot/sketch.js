
function setup() {
  
// 1. create the canvas. Make it 600 pixels square. 
  

}

function draw() {
  
// 2. Draw an ellipse
// Run the code to make sure it works before moving on.


// 3. Change the color of the ellipse when the mouse is pressed.
//    Use the following code, but put your colors where indicated
//    Remember to use the   fill()  command to set colors.

if (mouseIsPressed) {
 
   //  put one color here 
  
} else {
  
   // put a different color here
  
}  
  
  
  
}